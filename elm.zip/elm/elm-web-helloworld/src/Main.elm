module Main exposing (..)

import Html exposing (Html, div, text)
import Html.App
import Mouse exposing (Position)
import Keyboard

-- MODELS
type alias Model = { m : Position, total : Int}


init : ( Model, Cmd Msg )
init =
    ( {m = {x = 0, y = 0}, total = 0}, Cmd.none )


-- MESSAGES
type Msg = MouseMsg Position

-- VIEW
view : Model -> Html Msg
view model =
    div []
      [ div [] [ text (toString model.m) ]
      , div [] [ text (toString model.total) ]
      ]



-- UPDATE
update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        MouseMsg p ->
            ( { model | m = p, total = model.total + 1 }, Cmd.none )



-- SUBSCRIPTIONS
subscriptions : Model -> Sub Msg
subscriptions model = Mouse.moves MouseMsg



-- MAIN
main : Program Never
main =
    Html.App.program
        { init = init
        , view = view
        , update = update
        , subscriptions = subscriptions
        }
