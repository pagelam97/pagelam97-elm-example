# Android Compatibity

I'd love to know how easy or difficlt it would be to use `elm-ui`'s API to generate Android layouts.

This document is here to track any research that people want to do into the subject. The idea would be to link to specific Android documentation and/or describe an approach for each concept.


Full API coverage would be wonderful, though to here's a good place to start.

- Row/Column
- Nearby's
- Spacing/Padding