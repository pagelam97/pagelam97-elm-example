# Accessibility Resources

What are good resources that cover effective techniques for accessibility?

This can be talks, articles, papers, blogposts, whatever.

Ideally the list here should include a link and a brief description of what's interesting about the resource.

**TODO**