# Internationalization Resources

What are good resources that cover effective internationalization techniques?

This can be talks, articles, papers, blogposts, whatever.

Ideally the list here should include a link and a brief description of what's interesting about the resource.

- [How supporting Right-to-Left can expose your bad UX](https://www.youtube.com/watch?v=xpumLsaAWGw&t=3s) - A wonderful talk on Right-to-Left support and how it's not as obvious as it may seem.
  - [dir property](https://www.w3.org/International/questions/qa-html-dir)
