module Main exposing (..)

{-| -}

import Html
import MaskedInput


main =
    Html.text "Testing"
