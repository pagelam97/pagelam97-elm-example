# Examples

To compile these examples locally, run the following terminal commands:

```
git clone https://github.com/elm/browser.git
cd browser/examples
elm reactor
```

Now go to [`http://localhost:8000`](http://localhost:8000) and navigate to whatever Elm file you want to see.
