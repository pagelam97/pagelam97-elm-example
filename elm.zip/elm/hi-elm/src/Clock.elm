
module Clock exposing (..)

import Browser
import Html exposing (..)
import Task
import Time
import Html.Events exposing (onClick)

main = Browser.element { init = init, view = view, update = update, subscriptions = subscriptions } 

type alias T = { zone: Time.Zone, time: Time.Posix }
type alias Model = { value: T, paused: Bool }

init: () -> (Model, Cmd Msg)
init _ = (Model (T Time.utc(Time.millisToPosix 0)) False, Task.perform AdjustTimeZone Time.here)

type Msg = Tick Time.Posix | AdjustTimeZone Time.Zone | Toggle

update: Msg -> Model -> (Model, Cmd Msg)
update msg model = 
    case msg of
        Tick newTime -> 
            let
                oldValue = model.value
            in 
                ({ model | value = { oldValue | time = newTime}}
                , Cmd.none
                )
        AdjustTimeZone newZone -> 
            let 
                oldValue = model.value
            in
                ({ model | value = { oldValue | zone = newZone}}
                , Cmd.none
                )
        Toggle ->
            ({ model | paused = not model.paused}, Cmd.none)
                

subscriptions: Model -> Sub Msg
subscriptions model = 
    if model.paused then
        Sub.none
    else 
        Time.every 1000 Tick


view: Model -> Html Msg
view model =
    div [] [
        button [ onClick Toggle ] [ text (if model.paused then "继续" else "暂停")], 
        let
            hour    = String.fromInt (Time.toHour   model.value.zone model.value.time)
            minute  = String.fromInt (Time.toMinute model.value.zone model.value.time)
            second  = String.fromInt (Time.toSecond model.value.zone model.value.time)
        in
        h1 [] [ text ( hour ++ ":" ++ minute ++ ":" ++ second)]
    ]