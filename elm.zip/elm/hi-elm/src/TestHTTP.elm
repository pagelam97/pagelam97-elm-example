
module TestHTTP exposing (..)

import Browser
import Html exposing (Html, text,  pre, div, button)
import Http
import Html.Events exposing (onClick)

main = Browser.element { init = init, update = update, subscriptions = subscriptions, view = view }

type Model = Failure | Loading  | Success String


init : () -> (Model, Cmd Msg)
init _ = 
    (Loading, Cmd.none)

type Msg 
    = Load String
    | GotText (Result Http.Error String)

update: Msg -> Model -> (Model, Cmd Msg)
update msg model = 
    case msg of
        Load url -> 
            (Loading
            , Http.get 
                { url  = "http://localhost:8000/src/Form.elm"
                , expect = Http.expectString GotText
                }
            )
        GotText result ->
            case result of
                Ok fullText -> (Success fullText, Cmd.none)
                Err _ -> (Failure, Cmd.none)


subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.none


view: Model -> Html Msg
view model =
    div [] [
        button [ onClick (Load "http://localhost:8000/src/Form.elm") ] [ text "-"], 
        case model of
            Failure ->
                text "I was unable to load your book."
            Loading -> 
                text "Loading...."
            Success fullText ->
                pre [] [ text fullText]
    ]

