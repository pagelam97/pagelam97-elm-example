module UI exposing (..)

-- import Element exposing (
--     Element, el, text, row, column, paragraph, alignRight, fill,
--     width, height, px, rgb255, spacing, centerY, padding,
--     centerX, maximum
--     )

import Element exposing (..)
import Element.Background as Background
import Element.Border as Border
import Element.Font as Font exposing (bold, center, italic, justify, regular, slashedZero, underline, variant)
import Element.Input as Input
import Element.Region as Region
import String exposing (right)



-- import Debug


gray =
    rgb255 200 200 200


red =
    rgb255 210 0 0


blue =
    rgb255 0 0 200


white =
    rgb255 255 255 255


green =
    rgb255 86 182 139


url : String
url =
    "http://bw-qm-public.oss-cn-shenzhen.aliyuncs.com/qm/entityxwzx/fieldfm/37066e44-d760-4daf-bef6-59fc5df54a14.png?x-oss-process=image/resize,m_lfit,w_1440,limit_1/auto-orient,1/quality,q_100"


title : String
title =
    "新闻资讯标题新闻资讯标题新闻资讯标题新闻资讯新闻资讯标题新闻资讯标题新闻资讯标题新闻资讯新闻资讯标题新闻"


type Msg
    = Change String


update msg model =
    case msg of
        Change value ->
            value


main =
    Element.layout [] myPage



-- myTestelement


e : Element Msg
e =
    myElement


l : Element Msg
l =
    el [ alignLeft ] myElement


r : Element Msg
r =
    el [ alignRight ] myElement


cx =
    el [ centerX ] myElement


myAlignmentRow : Element Msg
myAlignmentRow =
    row [ padding 32, width fill, spaceEvenly ]
        [ myElement, myElement, myElement, myElement ]


myAlignmentRow2 : Element Msg
myAlignmentRow2 =
    row [ width fill, alignTop, spaceEvenly ] [ e, l, e ]


colG : Element Msg
colG =
    column [ Background.color green, height fill, width <| px 100 ] []


myRowG : Element Msg
myRowG =
    row [ width fill, spacing 8, alignBottom, height <| px 100 ]
        [ colG, colG ]


rowG : Element Msg
rowG =
    row [ Background.color green, width fill, height <| px 100 ] []


myColG : Element Msg
myColG =
    column [ width fill, spacing 8 ]
        [ rowG
        , rowG
        ]


myAlignmentCol : Element Msg
myAlignmentCol =
    column [ width fill ]
        [ myElement
        , el
            [ alignRight
            ]
            myElement
        ]


myWrappedRow : Element Msg
myWrappedRow =
    wrappedRow
        [ spaceEvenly, spacing 8, Background.color green ]
        [ myElement
        , myElement
        , myElement
        , myElement
        , myElement
        , myElement
        , myElement
        , el
            [ Border.rounded 4

            --, alignRight
            --, Background.color (rgb255 10 160 10)
            , Background.image url
            , Font.color (rgb255 255 255 255)

            --, padding 80
            , width <| px 80
            , height <| px 80

            --, width fill
            --, centerX
            --, centerY
            ]
            (text "stylish!")
        ]


myWrappedRow2 : Element Msg
myWrappedRow2 =
    wrappedRow
        []
        [ myElement
        , myElement
        , myElement
        , myElement
        , el
            [ Border.rounded 4

            --, Background.color (rgb255 10 160 10)
            , Background.image url
            , Font.color (rgb255 255 255 255)

            --, padding 80
            , width <| px 80
            , height <| px 80

            --, width fill
            --, centerX
            --, centerY
            ]
            (text "stylish!")
        , myElement
        , myElement
        , myElement
        ]


myDirectRow : Element Msg
myDirectRow =
    row
        [ spacing 8 ]
        [ myElement
        , myElement
        , myElement
        , myElement
        , el
            [ Border.rounded 4

            --, Background.color (rgb255 10 160 10)
            , Background.image url
            , Font.color (rgb255 255 255 255)

            --, padding 80
            , width <| px 80
            , height <| px 80

            --, width fill
            --, centerX
            --, centerY
            ]
            (text "stylish!")
        , myElement
        , myElement
        , myElement
        ]


file =
    "http://bwax-private.oss-cn-shenzhen.aliyuncs.com/cb/entityzcwd/4111db20-6792-480c-9fe1-5ade094877fb.xlsx?OSSAccessKeyId=LTAIvHO6oIk6Dh0M&Expires=1578058340&Signature=MV0cHz%2BrBjqsDPrGaqottXN6iyA%3D"


myCelMiddle : Element Msg
myCelMiddle =
    column [ height fill, width fill ]
        [ column [ padding 32, spacing 16, height fill ]
            [ el [] <|
                Input.text
                    [ Input.focusedOnLoad ]
                    { text = "HELLO"
                    , onChange = Change
                    , label = Input.labelAbove [] (text "Lunch")
                    , placeholder = Nothing
                    }
            , download [] { url = file, label = text "下载" }
            ]
        ]


myFronCol : Element msg
myFronCol =
    column [ width fill, height fill ]
        [ row
            [ padding 12
            , width fill
            , Background.color red
            ]
            [ column []
                [ el [] (text "HELLO WORLD")
                , el [] (text "HELLO WORLD")
                ]
            ]
        ]


myRow222 : Element msg
myRow222 =
    row []
        [ el [ height (px 400), width (px 100), Background.color green ] none
        , column
            [ spaceEvenly, height fill ]
            [ el [] (text "Top")
            , column
                []
                [ el [] (text "M1")
                , el [] (text "M2")
                , el [] (text "M3")
                ]
            , el [] (text "Bottom")
            ]
        ]


myRow333 : Element msg
myRow333 =
    row
        []
        [ image
            [ width (px 80) ]
            { src = "http://localhost:3200/SaiAuLogo.c8014053.png", description = "HELLO" }
        ]


myRow1 : Element msg
myRow1 =
    column
        [ spacing 20, padding 32 ]
        [ el [ onLeft (text "I'm bellow!") ] (text "I'm normal")
        , el
            []
            (text "test none")
        , el
            [ inFront <| el [ padding 10, Background.color blue ] none
            ]
            (text "test front")
        , el
            [ behindContent <| el [ padding 10, Background.color blue ] none
            ]
            (text "test behind")
        , el
            [ onLeft <| el [ padding 10, Background.color blue ] none
            ]
            (text "test left")
        , el
            [ onRight <| el [ padding 10, Background.color blue ] none
            ]
            (text "test right")
        , el
            [ above <| el [ padding 10, Background.color blue ] none
            ]
            (text "test above")
        , el
            [ below <| el [ padding 10, Background.color blue ] none
            ]
            (text "test below")
        ]


myCol : Element msg
myCol =
    column
        [ width fill
        , height fill
        ]
        [ el [] (text "HELLO WORLD")
        , el [ centerY, centerX ] (text "COOL")
        , el [] (text "MAN")
        ]


myRow : Element msg
myRow =
    row
        [ centerX, centerY, spacing 10 ]
        [ myElement
        , row [] [ myElement ]
        , column
            [ width fill
            ]
            [ paragraph [] [ text title ] ]
        , myElement
        ]


myElement : Element msg
myElement =
    el
        [ Border.rounded 4

        --, Background.color (rgb255 10 160 10)
        , Background.image url
        , Font.color (rgb255 255 255 255)

        --, padding 80
        , width <| px 80
        , height <| px 80

        --, width fill
        --, centerX
        --, centerY
        ]
        (text "stylish!")


myElement1 : Element msg
myElement1 =
    Element.row []
        [ Element.el
            [ Element.below (Element.text "I'm below!")
            ]
            (Element.text "I'm normal!")
        ]



-- el
--  [ Background.color (rgb255 240 0 245)
--   , Font.color (rgb255 255 255 255)
--   , Border.rounded 3
--   , padding 30
--  ]
--  (text "Just a test!         ")


myTestelement =
    -- el
    --     [ Background.color gray
    --     , Font.color (rgb255 255 255 255)
    --     , Border.rounded 4
    --     , Border.color green
    --     -- ,Border.solid
    --     , Border.widthEach
    --         { left = 20
    --         , right = 10
    --         , top = 3
    --         , bottom = 50
    --         }
    --     , padding 30
    --     ]
    --     (text "Just a test!!")
    el
        [ Background.color gray
        , Font.color gray
        , Font.size 20
        , Font.family
            [ Font.typeface "Helvetica"
            , Font.sansSerif
            ]
        , Font.underline
        , bold
        , regular
        , Font.shadow { blur = 1.5, color = green, offset = ( 1.5, 1.5 ) }
        , Font.letterSpacing 15
        ]
        (Element.text "000这是一段文字，它的作用是占位acas")


myTestinput : Element Msg
myTestinput =
    Element.el []
        (Input.text
            [ Input.focusedOnLoad ]
            { text = "HELLO"
            , onChange = Change
            , label = Input.labelLeft [] (text "Lunch")
            , placeholder = Nothing
            }
        )


myNavigation : Element msg
myNavigation =
    Element.row [ Region.navigation ]
        [ link [ Region.heading 1 ]
            { url = "http://fruits.com"
            , label = text "Best site ever"
            }
        ]



-- myPage : Element msg
-- myPage =
--     wrappedRow [ padding 10, spacing 30, width fill ] [ myElement, myElement, myElement, myElement, myElement, myElement, myElement, myElement, myElement, myElement, myElement, myElement, myElement, myElement, myElement, myElement, myElement, myElement, myElement, myElement, myElement, myElement, myElement, myElement, myElement, myElement, myElement, myElement, myElement ]


theTopelement : Element msg
theTopelement =
    el
        [ Background.color green
        , width fill
        , padding 50
        , center
        , Font.size 64
        , bold
        , Font.color (rgb255 255 255 255)
        ]
        (text "Just a test")


colorBlock : Element msg
colorBlock =
    el
        [ height <| px 150
        , width (px 150)
        , Background.color (rgb255 248 223 164)
        , center
        ]
        (text "这是一个色块")


colorBlockRow : Element msg
colorBlockRow =
    row
        [ width fill
        , spacing 100
        ]
        [ el [ alignLeft ] colorBlock
        , el [ centerX ] colorBlock
        , el [ alignRight ] colorBlock
        ]


colorBlockColumn : Element msg
colorBlockColumn =
    column
        [ width fill ]
        [ el [ alignRight ] colorBlock
        , el [ centerX ] colorBlock
        , el [ alignLeft ] colorBlock
        ]


myFooteleft : Element msg
myFooteleft =
    column
        [ Background.color (rgb255 0 122 204)
        , width <| px 700
        , padding 5
        ]
        [ el
            [ Font.color (rgb255 255 255 255)
            , Font.size 30
            , bold
            , padding 10
            , centerX
            ]
            (text """西游记  第一回""")
        , paragraph
            [ padding 10
            , Font.color (rgb255 255 255 255)
            , Font.size 25
            ]
            [ text """灵根育孕源流出
                    心性修持大道生
                    诗曰：混沌未分天地乱，茫茫渺渺无人见。自从盘古破鸿蒙，开辟从兹清浊辨。覆载群生仰至仁，发明万物皆成善。欲知造化会元功，须看《西游释厄传》。
                    盖闻天地之数，有十二万九千六百岁为一元。将一元分为十二会，乃子、丑、寅、卯、辰、巳、午、未、申、酉、戌、亥之十二支也。每会该一万八百岁。且就一日而论：子时得阳气而丑则鸡鸣，寅不通光而卯则日出，辰时食后而巳则挨排，日午天中而未则西蹉，申时晡而日落酉，戌黄昏而人定亥。譬于大数，若到戌会之终，则天地昏曚而万物否矣。再去五千四百岁，交亥会之初，则当黑暗，而两间人物俱无矣，故曰混沌。又五千四百岁，亥会将终，贞下起元，近子之会，而复逐渐开明。邵康节曰：“冬至子之半，天心无改移。一阳初动处，万物未生时。”到此天始有根。再五千四百岁，正当子会，轻清上腾，有日有月有星有辰。日月星辰，谓之四象。故曰天开于子。又经五千四百岁，子会将终，近丑之会，而逐渐坚实。《易》曰：“大哉乾元！至哉坤元！万物资生，乃顺承天。”至此，地始凝结。再五千四百岁，正当丑会，重浊下凝，有水有火有山有石有土。水火山石土，谓之五形。故曰地辟于丑。又经五千四百岁，丑会终而寅会之初，发生万物。历曰：“天气下降，地气上升；天地交合，群物皆生。”至此，天清地爽，阴阳交合。再五千四百岁，正当寅会，生人生兽生禽，正谓天地人，三才定位。故曰人生于寅。
                    感盘古开辟，三皇治世，五帝定伦，世界之间，遂分为四大部洲：曰东胜神洲，曰西牛贺洲，曰南赡部洲，曰北俱芦洲。这部书单表东胜神洲。海外有一国土，名曰傲来国。国近大海，海中有一座名山，唤为花果山。此山乃十洲之祖脉，三岛之来龙，自开清浊而立，鸿蒙判后而成。真个好山！有词赋为证，赋曰：势镇汪洋，威宁瑶海。势镇汪洋，潮涌银山鱼入穴；威宁瑶海，波翻雪浪蜃离渊。水火方隅高积土，东海之处耸崇巅。丹崖怪石，削壁奇峰。丹崖上彩凤双鸣，削壁前麒麟独卧。峰头时听锦鸡鸣，石窟每观龙出入。林中有寿鹿仙狐，树上有灵禽玄鹤。瑶草奇花不谢，青松翠柏长春。仙桃常结果，修竹每留云。一条涧壑藤萝密，四面原堤草色新。正是百川会处擎天柱，万劫无移大地根。那座山正当顶上，有一块仙石。其石有三丈六尺五寸高，有二丈四尺围圆。三丈六尺五寸高，按周天三百六十五度；二丈四尺围圆，按政历二十四气，上有九窍八孔，按九宫八卦。四面更无树木遮阴，左右倒有芝兰相衬。盖自开辟以来，每受天真地秀，日精月华，感之既久，遂有灵通之意，内育仙胎。一日迸裂，产一石卵，似圆球样大，因见风，化作一个石猴，五官俱备，四肢皆全。便就学爬学走，拜了四方，目运两道金光，射冲斗府，惊动高天上圣大慈仁者玉皇大天尊玄穹高上帝，驾座金阙云宫灵霄宝殿，聚集仙卿，见有金光焰焰，即命千里眼、顺风耳开南天门观看。二将果奉旨出门外，看的真，听的明，须臾回报道：“臣奉旨观听金光之处，乃东胜神洲海东傲来小国之界，有一座花果山，山上有一仙石，石产一卵，见风化一石猴，在那里拜四方，眼运金光，射冲斗府。如今服饵水食，金光将潜息矣。”玉帝垂赐恩慈曰：“下方之物，乃天地精华所生，不足为异。”
                    那猴在山中却会行走跳跃，食草木，饮涧泉，采山花，觅树果；与狼虫为伴，虎豹为群，獐鹿为友，猕猿为亲；夜宿石崖之下，朝游峰洞之中。真是“山中无甲子，寒尽不知年”。一朝天气炎热，与群猴避暑，都在松阴之下顽耍。你看他一个个：跳树攀枝，采花觅果；抛弹子，邷么儿；跑沙窝，砌宝塔；赶蜻蜓，扑蜡；参老天，拜菩萨；扯葛藤，编草帓；捉虱子，咬圪蚤；理毛衣，剔指甲；挨的挨，擦的擦；推的推，压的压；扯的扯，拉的拉。青松林下任他顽，绿水涧边随洗濯。一群猴子耍了一会，却去那山涧中洗澡，见那股涧水奔流，真个似滚瓜涌溅。古云禽有禽言，兽有兽语。众猴都道：“这股水不知是那里的水。我们今日赶闲无事，顺涧边往上溜头，寻看源流耍子去耶！”喊一声，都拖男挈女，唤弟呼兄，一齐跑来，顺涧爬山，直至源流之处，乃是一股瀑布飞泉。但见那一派白虹起，千寻雪浪飞。海风吹不断，江月照还依。冷气分青嶂，余流润翠微。潺湲名瀑布，真似挂帘帷。众猴拍手称扬道：“好水！好水！原来此处远通山脚之下，直接大海之波。”又道：“那一个有本事的，钻进去寻个源头出来不伤身体者，我等即拜他为王。”连呼了三声，忽见丛杂中跳出一个石猴，应声高叫道：“我进去！我进去！”好猴！也是他今日芳名显，时来大运通。有缘居此地，天遣入仙宫。
                    你看他瞑目蹲身，将身一纵，径跳入瀑布泉中，忽睁睛抬头观看，那里边却无水无波，明明朗朗的一架桥梁。他住了身，定了神，仔细再看，原来是座铁板桥，桥下之水，冲贯于石窍之间，倒挂流出去，遮闭了桥门。却又欠身上桥头，再走再看，却似有人家住处一般，真个好所在。但见那翠藓堆蓝，白云浮玉，光摇片片烟霞。虚窗静室，滑凳板生花。乳窟龙珠倚挂，萦回满地奇葩。锅灶傍崖存火迹，樽罍靠案见肴渣。石座石床真可爱，石盆石碗更堪夸。又见那一竿两竿修竹，三点五点梅花。几树青松常带雨，浑然像个人家。
                    看罢多时，跳过桥中间，左右观看，只见正当中有一石碣。碣上有一行楷书大字，镌着“花果山福地，水帘洞洞天”。石猿喜不自胜，急抽身往外便走，复瞑目蹲身，跳出水外，打了两个呵呵道：“大造化！大造化！”众猴把他围住问道：“里面怎么样？水有多深？”石猴道：“没水！没水！原来是一座铁板桥。桥那边是一座天造地设的家当。”众猴道：“怎见得是个家当？”石猴笑道：“这股水乃是桥下冲贯石窍，倒挂下来遮闭门户的。桥边有花有树，乃是一座石房。房内有石锅石灶、石碗石盆、石床石凳，中间一块石碣上，镌着‘花果山福地，水帘洞洞天’。真个是我们安身之处。里面且是宽阔，容得千百口老小。我们都进去住，也省得受老天之气。这里边刮风有处躲，下雨好存身。霜雪全无惧，雷声永不闻。烟霞常照耀，祥瑞每蒸熏。松竹年年秀，奇花日日新。”
                    众猴听得，个个欢喜，都道：“你还先走，带我们进去进去！”石猴却又瞑目蹲身，往里一跳，叫道：“都随我进来！进来！”那些猴有胆大的，都跳进去了；胆小的，一个个伸头缩颈，抓耳挠腮，大声叫喊，缠一会，也都进去了。跳过桥头，一个个抢盆夺碗，占灶争床，搬过来，移过去，正是猴性顽劣，再无一个宁时，只搬得力倦神疲方止。石猿端坐上面道：“列位呵，人而无信，不知其可。你们才说有本事进得来、出得去不伤身体者，就拜他为王。我如今进来又出去，出去又进来，寻了这一个洞天与列位安眠稳睡，各享成家之福，何不拜我为王？”众猴听说，即拱伏无违，一个个序齿排班，朝上礼拜，都称“千岁大王”。自此，石猿高登王位，将石字儿隐了，遂称美猴王。有诗为证，诗曰：三阳交泰产群生，仙石胞含日月精。借卵化猴完大道，假他名姓配丹成。内观不识因无相，外合明知作有形。历代人人皆属此，称王称圣任纵横。美猴王领一群猿猴、猕猴、马猴等，分派了君臣佐使，朝游花果山，暮宿水帘洞，合契同情，不入飞鸟之丛，不从走兽之类，独自为王，不胜欢乐。是以春采百花为饮食，夏寻诸果作生涯。秋收芋栗延时节，冬觅黄精度岁华。
                    """
            ]
        ]


myfooterright : Element Msg
myfooterright =
    column
        [ Background.color (rgb255 198 185 146)
        , width fill
        , padding 30
        ]
        [ el [] <|
            Input.text
                [ Input.focusedOnLoad ]
                { text = "HELLO"
                , onChange = Change
                , label = Input.labelLeft [ centerY ] (text "Lunch")
                , placeholder = Nothing
                }
        , el [] <|
            Input.text
                [ Input.focusedOnLoad ]
                { text = "HELLO"
                , onChange = Change
                , label = Input.labelLeft [ centerY ] (text "Lunch")
                , placeholder = Nothing
                }
        , row []
            [ column
                [ Background.color (rgb255 0 122 204)
                , width <| px 700
                , padding 5
                ]
                [ el
                    [ Font.color (rgb255 255 255 255)
                    , Font.size 30
                    , bold
                    , padding 10
                    , centerX
                    ]
                    (text """西游记  第二回""")
                , paragraph
                    [ padding 10
                    , Font.color (rgb255 255 255 255)
                    , Font.size 25
                    ]
                    [ text """诗曰：混沌未分天地乱，茫茫渺渺无人见。自从盘古破鸿蒙，开辟从兹清浊辨。覆载群生仰至仁，发明万物皆成善。欲知造化会元功，须看《西游释厄传》。
                    盖闻天地之数，有十二万九千六百岁为一元。将一元分为十二会，乃子、丑、寅、卯、辰、巳、午、未、申、酉、戌、亥之十二支也。每会该一万八百岁。且就一日而论：子时得阳气而丑则鸡鸣，寅不通光而卯则日出，辰时食后而巳则挨排，日午天中而未则西蹉，申时晡而日落酉，戌黄昏而人定亥。譬于大数，若到戌会之终，则天地昏曚而万物否矣。再去五千四百岁，交亥会之初，则当黑暗，而两间人物俱无矣，故曰混沌。又五千四百岁，亥会将终，贞下起元，近子之会，而复逐渐开明。邵康节曰：“冬至子之半，天心无改移。一阳初动处，万物未生时。”到此天始有根。再五千四百岁，正当子会，轻清上腾，有日有月有星有辰。日月星辰，谓之四象。故曰天开于子。又经五千四百岁，子会将终，近丑之会，而逐渐坚实。《易》曰：“大哉乾元！至哉坤元！万物资生，乃顺承天。”至此，地始凝结。再五千四百岁，正当丑会，重浊下凝，有水有火有山有石有土。水火山石土，谓之五形。故曰地辟于丑。又经五千四百岁，丑会终而寅会之初，发生万物。历曰：“天气下降，地气上升；天地交合，群物皆生。”至此，天清地爽，阴阳交合。再五千四百岁，正当寅会，生人生兽生禽，正谓天地人，三才定位。故曰人生于寅。
                    感盘古开辟，三皇治世，五帝定伦，世界之间，遂分为四大部洲：曰东胜神洲，曰西牛贺洲，曰南赡部洲，曰北俱芦洲。这部书单表东胜神洲。海外有一国土，名曰傲来国。国近大海，海中有一座名山，唤为花果山。此山乃十洲之祖脉，三岛之来龙，自开清浊而立，鸿蒙判后而成。真个好山！有词赋为证，赋曰：势镇汪洋，威宁瑶海。势镇汪洋，潮涌银山鱼入穴；威宁瑶海，波翻雪浪蜃离渊。水火方隅高积土，东海之处耸崇巅。丹崖怪石，削壁奇峰。丹崖上彩凤双鸣，削壁前麒麟独卧。峰头时听锦鸡鸣，石窟每观龙出入。林中有寿鹿仙狐，树上有灵禽玄鹤。瑶草奇花不谢，青松翠柏长春。仙桃常结果，修竹每留云。一条涧壑藤萝密，四面原堤草色新。正是百川会处擎天柱，万劫无移大地根。那座山正当顶上，有一块仙石。其石有三丈六尺五寸高，有二丈四尺围圆。三丈六尺五寸高，按周天三百六十五度；二丈四尺围圆，按政历二十四气，上有九窍八孔，按九宫八卦。四面更无树木遮阴，左右倒有芝兰相衬。盖自开辟以来，每受天真地秀，日精月华，感之既久，遂有灵通之意，内育仙胎。一日迸裂，产一石卵，似圆球样大，因见风，化作一个石猴，五官俱备，四肢皆全。便就学爬学走，拜了四方，目运两道金光，射冲斗府，惊动高天上圣大慈仁者玉皇大天尊玄穹高上帝，驾座金阙云宫灵霄宝殿，聚集仙卿，见有金光焰焰，即命千里眼、顺风耳开南天门观看。二将果奉旨出门外，看的真，听的明，须臾回报道：“臣奉旨观听金光之处，乃东胜神洲海东傲来小国之界，有一座花果山，山上有一仙石，石产一卵，见风化一石猴，在那里拜四方，眼运金光，射冲斗府。如今服饵水食，金光将潜息矣。”玉帝垂赐恩慈曰：“下方之物，乃天地精华所生，不足为异。”
                    """
                    ]
                ]
            ]
        ]


myPage : Element Msg
myPage =
    column
        [ width fill ]
        [ theTopelement, colorBlockRow, colorBlockColumn, myfooterright ]
