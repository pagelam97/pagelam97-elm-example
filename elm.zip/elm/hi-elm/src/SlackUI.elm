
module SlackUI exposing (main)

import Element exposing (..)
import Element.Background as Background
import Element.Border as Border
import Element.Font as Font
import Element.Input as Input
import Element.Region as Region
import Html exposing (Html)


sampleChannels =  ["elm", "elm-ui", "general"]
sampleActiveChannel = "elm-ui"

type alias Message = { author : String, time : String, text : String }

sampleMessages : List Message
sampleMessages =
    [ { author = "augustin82", time = "6:09AM", text = "@gampleman I think you need to `clip` the `scrollable` element, and that that element should be larger than its parent, which (I think) means that the containing parent should have a fixed width" }
    , { author = "u0421793", time = "6:22AM", text = "I’ve been trying to make a few links on a page in elm and elm-ui but I’ve not found a way to make it work because I haven’t found any examples of elm-ui which incorporate an anchor element" }
    , { author = "augustin82", time = "6:27AM", text = "@u0421793 what are you looking for exactly? do you have an Ellie where you've tried  doing some stuff?" }
    , { author = "icepac", time = "7:53 AM", text = "Anybody replied to @lango https://elmlang.slack.com/archives/C4F9NBLR1/p1541911789377400 About Animation vs Element ?" }
    , { author = "mgriffith", time = "8:00 AM", text = "You can use them together, for sure :smile: You just need to use `Element.htmlAttribute` to render the style attribute." }
    , { author = "duncan", time = "9:32 AM", text = "so ideally, it'd be nice to get the r,g,b,a components from a `Color` so that I could do the string interp (edited)" }
    , { author = "lango", time = "1:23 PM", text = "@mgriffith But that isn't really them 'working together' is it, its more they just happen to be together? For example, `elm-ui` has `background.gradient` but `elm-style-animation` only has `backgroundColor`. It's not clear to me how I could animation `elm-ui`'s `background.gradient` using `elm-animation`?" }
    , { author = "mgriffith", time = "4:28 PM", text = "@lango Oh, yeah I totally agree it isn’t seamless :smile: That’s why I’ve been putting a lot of time towards an API for animation for elm-ui.  But technically `elm-style-animation` and `elm-ui` can work together." }
    , { author = "eniac314", time = "6:49 AM", text = "It seems it it possible to press buttons without the event handler associated being fired when one clicks the thin area along the top border. In this example: https://ellie-app.com/3T4KLBKbnTQa1 it's possible to see the button moving without the counter increasing or decreasing. Is this due to the way I did the styling for the buttons? It seems to be related to the shadow (edited)" }
    , { author = "anthony.deschamps", time = "10:24 AM", text = "What's the most recent version of elm-ui/stylish-elephants that works on 0.18?" }
    , { author = "progger", time = "10:46 AM", text = "I've got some text that I'm laying out in a paragraph, and I want to put a link in there too.  Paragraph put the link on its own line though.  Shouldn't it all flow together?" }
    , { author = "progger", time = "11:22 AM", text = "Ha, I filed an issue about this back in oct.  Used my own workaround!" }
    ]


main: Html msg
main = 
    layout [ height fill ] <|
        row [ height fill, width fill ]
            [ channelPannel sampleChannels sampleActiveChannel, chatPanel sampleActiveChannel sampleMessages]

channelPannel: List String -> String -> Element msg
channelPannel channels activeChannel =
    let 
        activeChannelAttrs = [ Background.color <| rgb255 117 179 201, Font.bold ]
        channelAttrs = [ Region.announce, paddingXY 15 5, centerX, width <| fillPortion 10232351234 ]
        channelEl channel = 
            el
                (if channel == activeChannel then
                    activeChannelAttrs ++ channelAttrs
                else
                    channelAttrs
                )
            <|
                text ("# " ++ channel)
    in
    column
        [ height fill
        , width <| fillPortion 1
        , paddingXY 0 10
        , Background.color <| rgb255 92 99 118
        , spacing 20
        , Font.color <| rgb255 255 255 255
        ]
    <|
        List.map channelEl channels



gray = rgb255 200 200 200
red = rgb255 210 0 0
white = rgb255 255 255 255
green = rgb255 86 182 139


chatPanel channel messages = 
    let 
        header = 
            row 
                [ width fill 
                , spaceEvenly
                , paddingXY 20 5
                , Border.widthEach { bottom = 1, top = 0, left = 0, right = 0 }
                , Border.color gray
                ]
                [   el [spacing 10] <| text ("#" ++ channel)
                
                , Input.button
                    [ padding 5
                    --, centerX
                    
                    , height fill
                    , Border.width 1
                    , Border.rounded 3
                    , Border.color gray
                    , Border.dashed
                    ]
                    { onPress = Nothing
                    , label = text "Search"
                    }
                ]

        messageEntry message =
            column [ width fill, spacingXY 0 5, paddingXY 8 8 ]
                [ row [ spacingXY 10 0]
                    [ el [ Font.bold ] <| text message.author, text message.time]
                , paragraph [ spacing 130] [ text message.text ]
                ]

        messagePanel = 
            column [ padding 10, spacingXY 0 20, scrollbarY, width fill ] <|
                List.map messageEntry messages
        
        footer = 
            el [ alignBottom, padding 20, width fill ] <|
                row
                    [ spacingXY 2 0
                    , width fill
                    
                    , Border.width 2
                    , Border.rounded 4
                    , Border.color gray
                    ]
                    [ el
                        [ padding 5
                        , Border.widthEach { right = 2, left = 0, top = 0, bottom = 0 }
                        , Border.color gray
                        , mouseOver [ Background.color green ]
                        ]
                        <|
                            text "+"
                    , el [Background.color white ] none
                    ]
    in
    column 
        [ height fill, width <| fillPortion 4 ]
        [ header
        , messagePanel
        , footer
        ]


chat = el [ centerX, alignRight ] (text "chat!!")

fixedBox = el [ width <| px 1000 ] (text "")